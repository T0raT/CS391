function Header() {
  return (
    <header className="bg-[#9d0020] py-5 text-center font-futura text-calc-header text-white">
      Guitar Store Admin Panel
    </header>
  );
}

export default Header;
